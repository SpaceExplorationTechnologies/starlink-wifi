int main () {
  int *x;
  int *y;
  int z;
  if (y - x == 0) return;
  if ((y - x) == 0) return;
  if (y - z == 0) return;
  if ((y - z) == 0) return;
}

