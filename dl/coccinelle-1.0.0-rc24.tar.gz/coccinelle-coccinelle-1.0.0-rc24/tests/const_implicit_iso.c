void main(double y) { 
  const int x;

}
