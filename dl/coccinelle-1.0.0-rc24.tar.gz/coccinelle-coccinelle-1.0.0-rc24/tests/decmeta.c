int main () {
  decimal(TEN,FIVE) x1;
  decimal(10,5) x2;
  decimal(20,5) x3;
  return x1 + x2 + x3 + 6 + 7;
}
