int main () {
  return 12;
}
