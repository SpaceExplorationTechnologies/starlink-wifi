int main() {
        bool i3, i4, i5;
        int b;
}
