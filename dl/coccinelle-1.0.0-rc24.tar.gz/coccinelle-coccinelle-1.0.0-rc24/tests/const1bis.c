void foo(int j) { 
  const int i;
  int i;
  i++;
}
