int main() {
  foo(12);
  foo(x);
  foo(CONSTANT);
  foo('a');
  foo("string");
  foo(1.0001);
}
