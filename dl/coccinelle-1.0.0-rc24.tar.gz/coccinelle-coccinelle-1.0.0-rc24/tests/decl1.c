static int az_ioctl(int cmd, void *arg)
{
  int x;
  int y;
  return 0;
}

