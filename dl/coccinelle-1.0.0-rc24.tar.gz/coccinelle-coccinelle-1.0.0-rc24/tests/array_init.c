static int term[MAX_ECARDS] = { 1, 1, 1, 1, 1, 1, 1, 1 };
MODULE_PARM(term, "1-8i");

