int main () {
  int foo[4];
  int *x;
  return
	sizeof(foo) +
	sizeof(x);
}
