void foo(const char *text) {
   strcat(buf->data, text);
}
