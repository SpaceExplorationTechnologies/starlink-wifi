
static inline void alloc_resource(struct pci_dev *dev, int idx)
{
		DBG("PCI");
}
