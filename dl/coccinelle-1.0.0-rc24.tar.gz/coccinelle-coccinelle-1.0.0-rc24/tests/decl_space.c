int main () {
  int *x = y;
  int x = y;
}
