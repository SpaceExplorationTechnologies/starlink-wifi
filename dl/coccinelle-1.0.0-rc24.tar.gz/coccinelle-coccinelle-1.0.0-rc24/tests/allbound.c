int main () {
  foo(27);
  xxx(27);
}
