int main () {
  test();
  foo();
  foo();
  foo();
  endtest();
}
