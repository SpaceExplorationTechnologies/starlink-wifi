int main (int i) {
 f(v.fld, v, v.fld2);
}
