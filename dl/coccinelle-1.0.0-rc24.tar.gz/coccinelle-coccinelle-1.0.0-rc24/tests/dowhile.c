int main() {
  do {
    f();
  }
  while (0);
  g();
}
