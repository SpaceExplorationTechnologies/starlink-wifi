void f(int i) {


  x = 1/* comment*/ ;
  x = /* comment*/1 ;
}
