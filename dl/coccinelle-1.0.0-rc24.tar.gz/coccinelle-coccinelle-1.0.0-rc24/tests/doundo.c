s8	*noevent;

int main()
{
  const s8 (*queue_priority_mapping)[2];
  s8 *noevent;
  foo();
}
