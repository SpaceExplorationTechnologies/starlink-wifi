int main () {
  xxx();
  if(y) {
    rrr();
  }
}

int main () {
  xxx();
  if(y)
    rrr();
}


int d() {}

int main2 () {
  yyy();
  xxx();
}
