int func(int i) { 
        int x, y;
}
