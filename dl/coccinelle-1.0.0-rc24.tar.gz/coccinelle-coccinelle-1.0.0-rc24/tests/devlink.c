static void cm4000_release(dev_link_t *link);

int main () {
	memset(&dev->atr_csum,0,			
		sizeof(dev_link_t) - sizeof(dev_node));
}

int xmain () {
  dev_link_t x;
	memset(&dev->atr_csum,0,			
		sizeof(dev_link_t) - sizeof(dev_node));
}
