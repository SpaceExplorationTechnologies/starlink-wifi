int first () {
  return 0;
}

int foo() {
 a();
 a();
 a();
}

int last () {
  return 0;
}
