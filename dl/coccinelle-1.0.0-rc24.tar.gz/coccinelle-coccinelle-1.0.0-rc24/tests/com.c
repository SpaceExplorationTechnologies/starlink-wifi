int main() {
  foo();
  /* a comment */
  foo();
  /* a comment */
  foo();
  bar();
}
