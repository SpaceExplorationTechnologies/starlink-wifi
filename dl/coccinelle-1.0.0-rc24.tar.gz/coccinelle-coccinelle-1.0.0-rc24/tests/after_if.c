#ifdef ELMC_MULTICAST
static void set_multicast_list(struct net_device *dev);
#endif
static struct ethtool_ops netdev_ethtool_ops;
