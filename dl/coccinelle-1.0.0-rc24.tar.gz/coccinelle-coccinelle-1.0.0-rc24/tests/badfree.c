int main() {
  free(x);
  if (a) {
  foo(a,x,b);
  }
}
