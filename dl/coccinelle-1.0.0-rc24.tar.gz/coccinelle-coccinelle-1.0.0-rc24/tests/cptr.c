static const char *str = "...";
