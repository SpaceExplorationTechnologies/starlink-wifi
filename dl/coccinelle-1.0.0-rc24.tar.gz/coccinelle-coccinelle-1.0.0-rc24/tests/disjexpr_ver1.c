int main (int i) {
 f(v.fld);
}
