int main () {
  one();
  foo();
}
