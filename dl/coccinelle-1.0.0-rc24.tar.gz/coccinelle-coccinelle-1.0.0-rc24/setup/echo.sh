#!/bin/sh

echo $*
