int test1(int i) 
{
	foo();
	bar();
}


int test2(int i) 
{
	bar();
	foo();
}


int test3(int i) 
{
	bar();
}


int test4(int i) 
{
	bar();
	foo();
	foo();
}
