void main(int i)
{
	struct netdev *bc;

	if ((bc = ch->brdchan) == 0) {
 		tty->driver_data = NULL;
 		return -ENODEV;
 	}

}
