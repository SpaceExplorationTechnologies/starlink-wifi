int main() {
  f(12);
  x = f(12);
}
