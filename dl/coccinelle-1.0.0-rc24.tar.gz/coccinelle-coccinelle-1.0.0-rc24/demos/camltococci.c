int main () {
  foo(a0);
  bar();
}
