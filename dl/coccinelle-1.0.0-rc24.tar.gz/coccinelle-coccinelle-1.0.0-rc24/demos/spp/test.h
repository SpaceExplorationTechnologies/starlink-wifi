
#ifdef __BAR__
	#define __FOO__
#else
	#undef __FOO__
#endif
