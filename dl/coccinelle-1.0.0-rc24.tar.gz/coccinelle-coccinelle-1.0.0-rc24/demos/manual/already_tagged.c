/* diamond example */
void main(int i)
{

  foo();
  if(1) 
    bar(1);
  else
    bar(2);
  foobar();

}
